Release 4.1.1
===========

* Added RELEASE_NOTES.md

Release 4.1.0
===========

* Improved Jenkins build support
* Removed QtCreated IDE configuration files
* Made microbench library and header optional

Release 4.0.1
==========
(Starting point for release notes.)
