EPICS V4 release 4.5
====================

This release is one component of EPICS V4 release 4.5.

This is the first release of pvDatabaseCPP.

It provides functionality equivalent to pvDatabaseJava.


