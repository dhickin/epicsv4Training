TODO
===========

monitorPlugin
-------------

A debate is on-going about what semantics should be.

Must test record delete.
-------------------

Must test removing a record from the PVDatabase while a pvAccess client
is attached. Also why do both unlisten and detach exists?


create more regression tests
----------------

Currently only some simple tests exist. Most of the testing has been via the examples
